/*
Creating by Zelma Milev
*/
package com.zm.playground;

import com.zm.beans.Coupon;
import com.zm.dao.CouponDao;
import com.zm.db.DatabaseManager;
import com.zm.dbdao.CouponDBDAO;

import java.sql.SQLException;
import java.time.LocalDate;

import static com.zm.utils.DateUtils.convertToDataViaData;

public class testCoupon {
    public static void main(String[] args) throws SQLException {
        System.out.println("---Coupons-- start-------------");
//        DatabaseManager.dropAndCreate();
//        DatabaseManager.dropAndCreateCoupons();
//        DatabaseManager.dropAndCreateCoupons();

        CouponDao couponDao = new CouponDBDAO();
        couponDao.getAllCoupons().forEach(System.out::println);

        Coupon coupon1 = new Coupon(1, 1, 1, "coupon1T", "coupon1D", convertToDataViaData(LocalDate.of(2021, 01, 01)),
                convertToDataViaData(LocalDate.of(2022, 01, 01)), 100, 100.11, "11111111111111111");
        Coupon coupon2 = new Coupon(2, 2, 2, "coupon2T", "coupon2D", convertToDataViaData(LocalDate.of(2021, 02, 02)),
                convertToDataViaData(LocalDate.of(2022, 02, 02)), 200, 200.22, "22222222222222222");
        Coupon coupon3 = new Coupon(3, 3, 3, "coupon3T", "coupon3D", convertToDataViaData(LocalDate.of(2021, 03, 03)),
                convertToDataViaData(LocalDate.of(2022, 03, 03)), 300, 300.33, "33333333333333333");
        Coupon coupon4 = new Coupon(4, 4, 4, "coupon4T", "coupon4D", convertToDataViaData(LocalDate.now()),
                convertToDataViaData(LocalDate.of(2022, 04, 04)), 400, 400.44, "44444444444444444");
        Coupon coupon5 = new Coupon(5, 5, 5, "coupon5T", "coupon5D", convertToDataViaData(LocalDate.now()),
                convertToDataViaData(LocalDate.now().plusYears(1)), 500, 500.44, "555555555555555");
        System.out.println(coupon1);
        coupon1.toString();
        System.out.println(coupon1.getEndDate().toString());
        System.out.println(coupon1.getStartDate());
        System.out.println(coupon2);
        System.out.println(coupon3);
        System.out.println(coupon4);
        System.out.println(LocalDate.now().plusYears(1));

        System.out.println("---Coupons--insert-------------");
        couponDao.addCoupon(coupon1);
        couponDao.addCoupon(coupon2);
        couponDao.addCoupon(coupon3);
        couponDao.addCoupon(coupon4);
        couponDao.addCoupon(coupon5);
        couponDao.getAllCoupons().forEach(System.out::println);

        System.out.println("---Coupons-- get one-------------");
        System.out.println(couponDao.getOneCoupon(5));
//        couponDao.getOneCoupon(1).toString()
//        couponDao.getOneCoupon(4).toString();

        System.out.println("---Coupons-- update-------------");
        Coupon couponUpdate = couponDao.getOneCoupon(2);
        couponUpdate.setTitle("coupon2TUpd");
        couponUpdate.setDescription("coupon2DUpd");
        couponUpdate.setStartDate(convertToDataViaData(LocalDate.now()));
        couponUpdate.setEndDate(convertToDataViaData(LocalDate.now().plusMonths(11)));
        couponDao.updateCoupon(couponUpdate);
        System.out.println(couponDao.getOneCoupon(couponUpdate.getId()));

        System.out.println("---Coupons-- delete-------------");
        couponDao.deleteCoupon(1);
        couponDao.getAllCoupons().forEach(System.out::println);


        System.out.println("---INSERT_CUSTOMER_COUPON-------------");
        couponDao.addCouponPurchase(1,2);
        couponDao.addCouponPurchase(1,3);
        couponDao.addCouponPurchase(1,5);
        couponDao.addCouponPurchase(2,2);
        couponDao.addCouponPurchase(3,2);
        couponDao.addCouponPurchase(3,3);
        couponDao.addCouponPurchase(5,5);

        System.out.println("---delete_CUSTOMER_COUPON-------------");
        couponDao.deleteCouponPurchase(3,2);
//        System.out.println(couponDao.getOneCoupon(4));
        System.out.println("---Coupons-- end-------------");
    }
}
