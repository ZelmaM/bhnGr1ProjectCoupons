/*
Creating by Zelma Milev
*/
package com.zm.playground;

import com.zm.job.CouponExpirationDailyJob;

public class testJOB {
    public static void main(String[] args) {



        Thread thread = new Thread(new CouponExpirationDailyJob());
//        thread.setDaemon(true);
        thread.start();
    }
}
