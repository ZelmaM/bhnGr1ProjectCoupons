/*
Creating by Zelma Milev
*/
package com.zm.playground;

import com.zm.beans.Company;
import com.zm.dao.CompanyDao;
import com.zm.db.DatabaseManager;
import com.zm.dbdao.CompanyDBDAO;

import java.sql.SQLException;

public class testCompany {
    public static void main(String[] args) throws SQLException {
        System.out.println("---Companies-- start-------------");
//        DatabaseManager.dropAndCreate();
//        DatabaseManager.dropAndCreateCoupons();
//        DatabaseManager.dropAndCreateCompanies();

        CompanyDao companyDao = new CompanyDBDAO();
        companyDao.getAllCompanies().forEach(System.out::println);

        Company company1 = new Company(1, "c1Name", "c1Email", "c1Password");
        Company company2 = new Company(2, "c2Name", "c2Email", "c2Password");
        Company company3 = new Company(3, "c3Name", "c3Email", "c3Password");
        Company company4 = new Company(4, "c4Name", "c4Email", "c4Password");
        Company company5 = new Company(5, "c5Name", "c5Email", "c5Password");
        System.out.println(company1);
        System.out.println(company2);
        System.out.println(company3);
        System.out.println(company4);
        System.out.println(company5);

        System.out.println("---Companies--insert-------------");
        companyDao.addCompany(company1);
        companyDao.addCompany(company2);
        companyDao.addCompany(company3);
        companyDao.addCompany(company4);
        companyDao.addCompany(company5);
        companyDao.getAllCompanies().forEach(System.out::println);

        System.out.println("---Companies-- get one-------------");
        System.out.println(companyDao.getOneCompany(1));
//        companyDao.getOneCompany(1).toString()
//        companyDao.getOneCompany(4).toString();

        System.out.println("---Companies-- update-------------");
        Company cUpdate = companyDao.getOneCompany(2);
        cUpdate.setName("c2Upd");
        cUpdate.setPassword("c2PasswordUpd");
        companyDao.updateCompany(cUpdate);
        companyDao.getAllCompanies().forEach(System.out::println);

        System.out.println("---Companies-- delete-------------");
        companyDao.deleteCompany(4);
        companyDao.getAllCompanies().forEach(System.out::println);
        System.out.println("---Companies-- isCompanyExists-------------");
        System.out.println(companyDao.isCompanyExists("c1Email", "c1Password"));
        System.out.println(companyDao.isCompanyExists("c1Email", "c2Password"));
        System.out.println(companyDao.isCompanyExists("c3Email", "c3Password"));

//        if (companyDao.isCompanyExists("c1Email", "c1Password")) {
//            System.out.println("c1Email" + " exist");
//        } else {
//            System.out.println("c1Email" + "not exist");
//        }
//        if (companyDao.isCompanyExists("c1Email", "c2Password")) {
//            System.out.println("c12Email" + " exist");
//        } else {
//            System.out.println("c12Email" + " not exist");
//        }

//        System.out.println(companyDao.getOneCompany(4));
        System.out.println("---Companies-- end-------------");
    }
}

