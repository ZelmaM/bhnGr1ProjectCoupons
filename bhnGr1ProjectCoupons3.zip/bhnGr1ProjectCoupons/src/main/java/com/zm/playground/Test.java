/*
Creating by Zelma Milev
*/
package com.zm.playground;

import com.zm.beans.Company;
import com.zm.beans.Coupon;
import com.zm.beans.Customer;
import com.zm.dao.CompanyDao;
import com.zm.dao.CouponDao;
import com.zm.dao.CustomerDao;
import com.zm.db.DatabaseManager;
import com.zm.dbdao.CompanyDBDAO;
import com.zm.dbdao.CouponDBDAO;
import com.zm.dbdao.CustomerDBDAO;
import com.zm.utils.ArtUtils;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;

import static com.zm.utils.DateUtils.convertToDataViaData;

public class Test {
    public static void main(String[] args) throws SQLException {
        System.out.println("START ");

        DatabaseManager.dropAndCreate();

        System.out.println(ArtUtils.CUSTOMER);

        CustomerDao customerDao = new CustomerDBDAO();
        customerDao.getAllCustomers().forEach(System.out::println);

        Customer c1 = new Customer(1, "c1fName", "c1lName", "c1Em", "c1Pass");
        Customer c2 = new Customer(2, "c2fName", "c2lName", "c2Em", "c2Pass");
        Customer c3 = new Customer(3, "c3fName", "c3lName", "c3Em", "c3Pass");
        Customer c4 = new Customer(4, "c4fName", "c4lName", "c4Em", "c4Pass");
        Customer c5 = new Customer(5, "c5fName", "c5lName", "c5Em", "c5Pass");

        System.out.println(ArtUtils.INSERT);
        customerDao.addCustomer(c1);
        customerDao.addCustomer(c2);
        customerDao.addCustomer(c3);
        customerDao.addCustomer(c4);
        customerDao.addCustomer(c5);
        customerDao.getAllCustomers().forEach(System.out::println);
        System.out.println(ArtUtils.UPDATE);
        Customer cUpdate = customerDao.getOneCustomer(2);
        cUpdate.setFirstName("c2FUpd");
        cUpdate.setLastName("c2LUpd");
        cUpdate.setPassword("c2PassUpd");
        customerDao.updateCustomer(cUpdate);
        System.out.println(customerDao.getOneCustomer(cUpdate.getId()));

        System.out.println(ArtUtils.GET_ONE);
        System.out.println(customerDao.getOneCustomer(1));
        System.out.println(customerDao.getOneCustomer(3));

        System.out.println(ArtUtils.DELETE);
        customerDao.deleteCustomer(4);

        System.out.println(ArtUtils.GET_ALL);
        customerDao.getAllCustomers().forEach(System.out::println);
        System.out.println("----- isCustomerExists-------------");
        if (customerDao.isCustomerExists("c1Em", "c1Pass")) {
            System.out.println(customerDao.getCustomerID("c1Em", "c1Pass") + "==>" + "c1Em" + "c1Pass");
        } else System.out.println(" not exists ==>" + "c1Em" +"/" + "c1Pass");
        if (customerDao.isCustomerExists("c1Em", "c2Pass")) {
            System.out.println(customerDao.getCustomerID("c1Em", "c2Pass") + "==>" + "c1Em" + "c2Pass");
        } else System.out.println(" not exists==>" + "c1Em" +"/" + "c2Pass");
        if (customerDao.isCustomerExists("c3Em", "c3Pass")) {
            System.out.println(customerDao.getCustomerID("c3Em", "c3Pass") + "-->"
                    + "c3Em" + "/" + "c3Pass" + "exist");
        } else {
            System.out.println("-->" + "c3Em" + "/" + "c3Pass" + " not exist");

        }

        System.out.println(ArtUtils.COMPANY);
        CompanyDao companyDao = new CompanyDBDAO();
        companyDao.getAllCompanies().forEach(System.out::println);
        Company company1 = new Company(1, "c1Name", "c1Email", "c1Password");
        Company company2 = new Company(2, "c2Name", "c2Email", "c2Password");
        Company company3 = new Company(3, "c3Name", "c3Email", "c3Password");
        Company company4 = new Company(4, "c4Name", "c4Email", "c4Password");
        Company company5 = new Company(5, "c5Name", "c5Email", "c5Password");

        System.out.println(ArtUtils.INSERT);
        companyDao.addCompany(company1);
        companyDao.addCompany(company2);
        companyDao.addCompany(company3);
        companyDao.addCompany(company4);
        companyDao.addCompany(company5);
        companyDao.getAllCompanies().forEach(System.out::println);

        System.out.println(ArtUtils.UPDATE);
        Company cUpd = companyDao.getOneCompany(2);
        cUpd.setName("c2Upd");
        cUpd.setPassword("c2PasswordUpd");
        companyDao.updateCompany(cUpd);
        companyDao.getAllCompanies().forEach(System.out::println);

        System.out.println(ArtUtils.GET_ONE);
        System.out.println(companyDao.getOneCompany(cUpd.getId()));
        System.out.println(companyDao.getOneCompany(5));


        System.out.println(ArtUtils.DELETE);
        companyDao.deleteCompany(4);

        System.out.println(ArtUtils.GET_ALL);
        companyDao.getAllCompanies().forEach(System.out::println);
        System.out.println("----- isCompanyExists-------------");
        if (companyDao.isCompanyExists("c1Email", "c1Password")) {
            System.out.println(companyDao.getCompanyID("c1Email", "c1Password") + "==>" + "c1Email" + "c1Password");
        } else System.out.println(" not exists ==>" + "c1Email" + "c1Password");
        if (companyDao.isCompanyExists("c1Email", "c2Password")) {
            System.out.println(companyDao.getCompanyID("c1Email", "c2Password") + "==>" + "c1Email" + "c2Password");
        } else System.out.println(" not exists==>" + "c1Email" + "c2Password");
        if (companyDao.isCompanyExists("c3Email", "c3Password")) {
            System.out.println(companyDao.getCompanyID("c3Email", "c3Password") + "==>" + "c3Email" + "c3Password");
        } else System.out.println(" not exists==>" + "c3Email" + "c3Password");


        System.out.println(ArtUtils.COUPON);
        CouponDao couponDao = new CouponDBDAO();
        couponDao.getAllCoupons().forEach(System.out::println);

        Coupon coupon1 = new Coupon(1, 1, 1, "coupon1T", "coupon1D", convertToDataViaData(LocalDate.of(2021, 01, 01)),
                convertToDataViaData(LocalDate.of(2022, 01, 01)), 100, 100.11, "11111111111111111");
        Coupon coupon2 = new Coupon(2, 2, 2, "coupon2T", "coupon2D", convertToDataViaData(LocalDate.of(2021, 02, 02)),
                convertToDataViaData(LocalDate.of(2022, 02, 02)), 200, 200.22, "22222222222222222");
        Coupon coupon3 = new Coupon(3, 3, 3, "coupon3T", "coupon3D", convertToDataViaData(LocalDate.of(2021, 03, 03)),
                convertToDataViaData(LocalDate.of(2022, 03, 03)), 300, 300.33, "33333333333333333");
        Coupon coupon4 = new Coupon(4, 4, 4, "coupon4T", "coupon4D", convertToDataViaData(LocalDate.now()),
                convertToDataViaData(LocalDate.of(2022, 04, 04)), 400, 400.44, "44444444444444444");
        Coupon coupon5 = new Coupon(5, 5, 5, "coupon5T", "coupon5D", convertToDataViaData(LocalDate.now()),
                convertToDataViaData(LocalDate.now().plusYears(1)), 500, 500.44, "555555555555555");
        Coupon coupon6 = new Coupon(6, 5, 3, "coupon6T", "coupon6D", Date.valueOf(LocalDate.now()),
                Date.valueOf(LocalDate.now().plusDays(100)), 653, 500.66, "666666655555555333333666");

        Coupon coupon7 = new Coupon(7, 5, 2, "coupon7T", "coupon7D", convertToDataViaData(LocalDate.now()),
                convertToDataViaData(LocalDate.now().plusDays(200)), 752, 500.77, "7777777555552222");

        System.out.println(ArtUtils.INSERT);
        couponDao.addCoupon(coupon1);
        couponDao.addCoupon(coupon2);
        couponDao.addCoupon(coupon3);
        couponDao.addCoupon(coupon4);
        couponDao.addCoupon(coupon5);
        couponDao.addCoupon(coupon6);
        couponDao.addCoupon(coupon7);
        couponDao.getAllCoupons().forEach(System.out::println);

        System.out.println(ArtUtils.UPDATE);
        Coupon couponUpdate = couponDao.getOneCoupon(2);
        couponUpdate.setTitle("coupon2TUpd");
        couponUpdate.setDescription("coupon2DUpd");
        couponUpdate.setStartDate(convertToDataViaData(LocalDate.now()));
        couponUpdate.setEndDate(convertToDataViaData(LocalDate.now().plusMonths(11)));
        couponDao.updateCoupon(couponUpdate);
        System.out.println(couponDao.getOneCoupon(couponUpdate.getId()));

        System.out.println(ArtUtils.GET_ONE);
        System.out.println(couponDao.getOneCoupon(5));

        System.out.println(ArtUtils.DELETE);
        couponDao.deleteCoupon(1);

        System.out.println(ArtUtils.GET_ALL);
        couponDao.getAllCoupons().forEach(System.out::println);

        System.out.println("---INSERT_CUSTOMER_COUPON-------------");
        couponDao.addCouponPurchase(1, 2);
        couponDao.addCouponPurchase(1, 3);
        couponDao.addCouponPurchase(1, 5);
        couponDao.addCouponPurchase(2, 2);
        couponDao.addCouponPurchase(3, 2);
        couponDao.addCouponPurchase(3, 3);
        couponDao.addCouponPurchase(5, 5);

        System.out.println("---delete_CUSTOMER_COUPON-------------");
        couponDao.deleteCouponPurchase(3, 2);
        System.out.println("END");

    }
}
