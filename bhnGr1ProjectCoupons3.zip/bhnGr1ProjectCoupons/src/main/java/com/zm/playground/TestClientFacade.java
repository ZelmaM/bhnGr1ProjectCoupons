/*
Creating by Zelma Milev
*/
package com.zm.playground;

import com.zm.beans.*;
import com.zm.db.ConnectionPool;
import com.zm.exceptions.CouponSystemException;
import com.zm.facades.AdminFacade;
import com.zm.facades.CompanyFacade;
import com.zm.facades.CustomerFacade;
import com.zm.facades.LoginManager;
import com.zm.job.CouponExpirationDailyJob;
import com.zm.utils.ArtUtils;
import com.zm.utils.CreationUtils;

import java.sql.SQLException;
import java.time.LocalDate;

import static com.zm.utils.DateUtils.convertToDataViaData;

public class TestClientFacade {
    public static void main(String[] args) throws SQLException, CouponSystemException, InterruptedException {
        System.out.println("START");
        CreationUtils.CreateFoundation();

        Thread thread = new Thread(new CouponExpirationDailyJob());
        thread.setDaemon(true);
        thread.start();

        AdminFacade adminFacade = (AdminFacade) LoginManager.getInstance().login("admin@admin.com", "admin", ClientType.ADMINISTRATOR);
        if (adminFacade != null) {
            testAdministrator(adminFacade);
        } else {
            System.out.println("You have not ADMINISTRATOR access privileges");
        }

        CompanyFacade companyFacade = (CompanyFacade) LoginManager.getInstance().login("c5Email", "c5Password", ClientType.COMPANY);
        if (companyFacade != null) {
            testCompanyFacade(companyFacade);
        } else {
            System.out.println(" COMPANY access denied");
        }

        CustomerFacade customerFacade = (CustomerFacade) LoginManager.getInstance().login("c3Em", "c3Pass", ClientType.CUSTOMER);
        if (companyFacade != null) {
            testCustomerFacade(customerFacade);
        } else {
            System.out.println(" CUSTOMER access denied");
        }

        ConnectionPool.getInstance().closeAllConnections();

        System.out.println("END");


    }
    public static void testAdministrator(AdminFacade adminFacade) throws CouponSystemException, SQLException {
        System.out.println(ArtUtils.ADMIN_FACADE);
        System.out.println("--- ADMINISTRATOR ---TEST-----STARTED---");
        System.out.println("----- Add companies---------------------");
        Company company = new Company("c1Name", "c1Email", "c1Password");
        try {
            adminFacade.addCompany(company);
            System.out.println(company.toString()+" === Added successfully === ");
        } catch (CouponSystemException e) {
            System.out.println( company.toString()+ " !!! not added !!!  <"+e.getMessage()+">");
        }
         company = new Company("cA7Name", "cA7Email", "cA7Password");
        try {
            adminFacade.addCompany(company);
            System.out.println(company.toString() + "=== Added successfully ===");
        } catch (CouponSystemException e) {
            System.out.println(company.toString() + " !!! not added !!!  <" + e.getMessage() + ">");
        }

        System.out.println("----- Update companies---------------------");
        adminFacade.updateCompany(new Company(16, "cA7Name", "cA7Email", "cA7Password"));
        adminFacade.updateCompany(new Company(6, "cA67Name", "cA7Email", "cA7Password"));
        System.out.println(adminFacade.getOneCompany(6));
        adminFacade.updateCompany(new Company(6, "cA7Name", "cA7EmailU", "cA7PasswordU"));
        System.out.println(adminFacade.getOneCompany(6));
        System.out.println("----- Delete companies---------------------");
        adminFacade.deleteCompany(15);
        adminFacade.deleteCompany(1);
        System.out.println("----- Show company---------------------");
        System.out.println(adminFacade.getOneCompany(1));
        adminFacade.getOneCompany(7);
        System.out.println(adminFacade.getOneCompany(17));
        System.out.println("----- Show list of companies---------------------");
        adminFacade.getAllCompanies().forEach(System.out::println);

        System.out.println("----------------ADD CUSTOMER-----------");
        adminFacade.getAllCustomers().forEach(System.out::println);
        Customer c1 = new Customer(1, "c1fName", "c1lName", "c1Emnew", "c1Pass");
        Customer c4 = new Customer(4, "c4fName", "c4lName", "c4Emnew", "c4Pass");

        try {
            adminFacade.addCustomer(c1);
            System.out.println("Customer " + c1.getFirstName() + "_" + c1.getLastName() + " Added successfully");
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Customer " + c1.getFirstName() + "_" + c1.getLastName() + " is not added ");
        }
        try {
            adminFacade.addCustomer(c4);
            System.out.println("Customer " + c4.getFirstName() + "_" + c4.getLastName() + " Added successfully");
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Customer " + c4.getFirstName() + "_" + c4.getLastName() + " is not added ");
        }
        System.out.println("----------------SHOW ALL CUSTOMER-----------");
        adminFacade.getAllCustomers().forEach(System.out::println);
        System.out.println("--- UPDATE CUSTOMER----------");
        adminFacade.updateCustomer(new Customer(7, "c4fNameu", "c4lNameu", "c4Emn", "c4Pass"));
        System.out.println("--- SHOW ONE CUSTOMER----------");
        System.out.println(adminFacade.getOneCustomer(1));


        System.out.println("--- DELETE CUSTOMER----------");
        adminFacade.deleteCustomer(6);
        adminFacade.deleteCustomer(8);
        adminFacade.deleteCustomer(9);
        adminFacade.deleteCustomer(6);
        adminFacade.deleteCustomer(10);

        System.out.println("--- ADMINISTRATOR ---TEST-----ENDED---");

    }

    public static void testCompanyFacade(CompanyFacade companyFacade) throws SQLException, CouponSystemException {
        System.out.println(ArtUtils.COMPANY_FACADE);
        System.out.println("--- COMPANY #" + companyFacade.getCompanyID() + " ---TEST-----STARTED---");
        System.out.println("--- Company details-----------------");
        System.out.println(companyFacade.getCompanyDetails());
        System.out.println("--- All Companies coupons-----------------");
        try {
            companyFacade.getCompanyCoupons().forEach(System.out::println);
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("--- All Companies coupons per category-----------------");

        try {
            companyFacade.getCompanyCoupons(Category.ELECTRICITY).forEach(System.out::println);

        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }
        try {
            companyFacade.getCompanyCoupons(Category.FOOD).forEach(System.out::println);

        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("--- All Companies coupons price less than max-----------------");
        try {
            companyFacade.getCompanyCoupons(500.70).forEach(System.out::println);

        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("--- add Companies coupons-----------------");
        try {
            companyFacade.addCoupon(new Coupon(15, 5, 5, "coupon5Tnew", "coupon5D", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not added");
        }
        try {
            companyFacade.addCoupon(new Coupon(15, 5, 5, "coupon5T", "coupon5D", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not added");
        }
        try {
            companyFacade.addCoupon(new Coupon(15, 3, 2, "coupon5Tnew0", "coupon5D", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not added");
        }
        try {
            companyFacade.addCoupon(new Coupon(15, 5, 1, "coupon5Tnew11", "coupon5D", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not added");
        }
        try {
            companyFacade.addCoupon(new Coupon(1, 5, 7, "T- 1", "coupon5D", convertToDataViaData(LocalDate.now().minusDays(1)),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "pag tokef1"));
            companyFacade.addCoupon(new Coupon(1, 5, 7, "T- 2", "coupon5D", convertToDataViaData(LocalDate.now().minusDays(2)),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "pag tokef1"));
            companyFacade.addCoupon(new Coupon(1, 5, 7, "T- 3", "coupon5D", convertToDataViaData(LocalDate.now().minusDays(3)),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "pag tokef1"));
            companyFacade.addCoupon(new Coupon(1, 5, 7, "T- 4", "coupon5D", convertToDataViaData(LocalDate.now().minusDays(4)),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "pag tokef1"));
            companyFacade.addCoupon(new Coupon(1, 5, 2, "T- 5", "coupon5D", convertToDataViaData(LocalDate.now().minusDays(15)),
                    convertToDataViaData(LocalDate.now().minusDays(1)), 700, 600.44, "pag tokef1"));
            companyFacade.addCoupon(new Coupon(1, 5, 2, "T- 6", "coupon5D", convertToDataViaData(LocalDate.now().minusDays(15)),
                    convertToDataViaData(LocalDate.now().minusDays(1)), 700, 600.44, "pag tokef1"));
            companyFacade.addCoupon(new Coupon(1, 5, 4, "T- 7", "coupon5D", convertToDataViaData(LocalDate.now().minusDays(15)),
                    convertToDataViaData(LocalDate.now().minusDays(1)), 700, 600.44, "pag tokef1"));
            companyFacade.addCoupon(new Coupon(1, 5, 4, "T- 8", "coupon5D", convertToDataViaData(LocalDate.now().minusDays(15)),
                    convertToDataViaData(LocalDate.now().minusDays(1)), 700, 600.44, "pag tokef1"));
            companyFacade.addCoupon(new Coupon(1, 5, 6, "T- 9", "coupon5D", convertToDataViaData(LocalDate.now().minusDays(15)),
                    convertToDataViaData(LocalDate.now().minusDays(1)), 700, 600.44, "pag tokef1"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not added");
        }
        try {
            companyFacade.getCompanyCoupons().forEach(System.out::println);
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("--- delete Companies coupons-----------------");
        try {
            companyFacade.deleteCoupon(20);
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not deleted");
        }
        try {
            companyFacade.deleteCoupon(8);
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not deleted");
        }

        System.out.println("--- update Companies coupons-----------------");
        try {
            companyFacade.updateCoupon(new Coupon(15, 3, 2, "coupon5Tnew0", "coupon5D", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not updated");
        }
        try {
            companyFacade.updateCoupon(new Coupon(15, 5, 2, "coupon5Tnew", "coupon5up", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 700, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not updated");
        }
        try {
            companyFacade.updateCoupon(new Coupon(8, 5, 2, "coupon5Tnew", "coupon5u22p", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 750, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage() + "Coupon is not updated");
        }
        try {
            companyFacade.getCompanyCoupons().forEach(System.out::println);
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("--- COMPANY #" + companyFacade.getCompanyID() + " ---TEST-----ENDED---");
    }

    private static void testCustomerFacade(CustomerFacade customerFacade) throws SQLException {
        System.out.println(ArtUtils.CUSTOMER_FACADE);
        System.out.println("--- CUSTOMER #" + customerFacade.getCustomerID() + " ---TEST-----STARTED---");
        System.out.println("--- CUSTOMER details-----------------");
        System.out.println(customerFacade.getCustomerDetails());
        System.out.println("--- All CUSTOMERS coupons-----------------");
        try {
            customerFacade.getCustomerCoupons().forEach(System.out::println);
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("--- All CUSTOMER coupons per category-----------------");

        try {
            customerFacade.getCustomerCoupons(Category.ELECTRONIC).forEach(System.out::println);
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }
        try {
            customerFacade.getCustomerCoupons(Category.VACATION).forEach(System.out::println);

        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("--- All CUSTOMER coupons price less than max-----------------");
        try {
            customerFacade.getCustomerCoupons(500.00).forEach(System.out::println);
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("--- add CUSTOMER coupons-----------------");
        try {
            customerFacade.purchaseCoupon(new Coupon(8, 5, 2, "coupon5Tnew", "coupon5u22p", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 750, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        } catch (SQLException s) {
            System.out.println(s.getMessage() + "<" + s.getErrorCode() + ">");
        }
        try {
            customerFacade.purchaseCoupon(new Coupon(3, 5, 2, "coupon5Tnew", "coupon5u22p", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 750, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        } catch (SQLException s) {
            System.out.println(s.getMessage() + "<" + s.getErrorCode() + ">");
        }
        try {
            customerFacade.purchaseCoupon(new Coupon(2, 5, 2, "coupon5Tnew", "coupon5u22p", convertToDataViaData(LocalDate.now()),
                    convertToDataViaData(LocalDate.now().plusYears(1)), 750, 600.44, "555555555555555"));
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        } catch (SQLException s) {
            System.out.println(s.getMessage() + "<" + s.getErrorCode() + ">");
        }
        try {
            customerFacade.purchaseCoupon(10);
            customerFacade.purchaseCoupon(11);
            customerFacade.purchaseCoupon(12);
            customerFacade.purchaseCoupon(13);
            customerFacade.purchaseCoupon(14);
            customerFacade.purchaseCoupon(15);
            customerFacade.purchaseCoupon(16);
            customerFacade.purchaseCoupon(17);
            customerFacade.purchaseCoupon(18);

        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        } catch (SQLException s) {
            System.out.println(s.getMessage() + "<" + s.getErrorCode() + ">");
        }

        try {
            customerFacade.getCustomerCoupons().forEach(System.out::println);
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }


        System.out.println("--- CUSTOMER #" + customerFacade.getCustomerID() + " ---TEST-----ENDED---");

    }
}