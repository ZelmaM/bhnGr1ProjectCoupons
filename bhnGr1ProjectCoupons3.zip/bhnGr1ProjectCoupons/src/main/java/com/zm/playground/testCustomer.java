/*
Creating by Zelma Milev
*/
package com.zm.playground;

import com.zm.beans.Customer ;
import com.zm.dao.CustomerDao;
import com.zm.db.DatabaseManager;
import com.zm.dbdao.CustomerDBDAO;

import java.sql.SQLException;

public class testCustomer {
    public static void main(String[] args) throws SQLException {
        System.out.println("---Customers-- start-------------");
//        DatabaseManager.dropAndCreate();
//        DatabaseManager.dropAndCreateCoupons();
//        DatabaseManager.dropAndCreateCustomers();

        CustomerDao customerDao = new CustomerDBDAO();
        customerDao.getAllCustomers().forEach(System.out::println);

        Customer  c1 = new Customer (1, "c1fName","c1lName", "c1Em", "c1Pass");
        Customer  c2 = new Customer (2, "c2fName","c2lName","c2Em", "c2Pass");
        Customer  c3 = new Customer (3, "c3fName","c3lName" ,"c3Em", "c3Pass");
        Customer  c4 = new Customer (4, "c4fName","c4lName" ,"c4Em", "c4Pass");
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        System.out.println(c4);

        System.out.println("---Customers--insert-------------");
        customerDao.addCustomer (c1);
        customerDao.addCustomer (c2);
        customerDao.addCustomer (c3);
        customerDao.addCustomer (c4);
        customerDao.getAllCustomers().forEach(System.out::println);

        System.out.println("---Customers-- get one-------------");
        System.out.println(customerDao.getOneCustomer (1));
//        customerDao.getOneCustomer (1).toString()
//        customerDao.getOneCustomer (4).toString();

        System.out.println("---Customers-- update-------------");
        Customer  cUpdate = customerDao.getOneCustomer (2);
        cUpdate.setFirstName("c2FUpd");
        cUpdate.setLastName("c2LUpd");
        cUpdate.setPassword("c2PassUpd");
        customerDao.updateCustomer (cUpdate);
        customerDao.getAllCustomers().forEach(System.out::println);

        System.out.println("---Customers-- delete-------------");
        customerDao.deleteCustomer (4);
        customerDao.getAllCustomers().forEach(System.out::println);
//        System.out.println(customerDao.getOneCustomer (4));
        System.out.println("---Customers-- end-------------");
    }
}
