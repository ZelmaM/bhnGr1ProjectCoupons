package com.zm.beans;

public enum ClientType {
    ADMINISTRATOR,
    COMPANY,
    CUSTOMER
}
