/*
Creating by Zelma Milev
*/
package com.zm.job;

import com.zm.beans.Coupon;
import com.zm.dao.CouponDao;
import com.zm.dbdao.CouponDBDAO;
import com.zm.exceptions.CouponSystemException;
import com.zm.facades.CompanyFacade;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static com.zm.utils.DateUtils.convertToDataViaData;

public class CouponExpirationDailyJob implements Runnable {
    @Override
    public void run() {
        CouponDao couponDao = new CouponDBDAO();
        try {
            if (!couponDao.isExpiredCouponExists()) {
                throw new CouponSystemException(" <SYSTEM WARNING> Not Expired Coupons");
            }
                System.out.println("<SYSTEM WARNING> START SYSTEM DELETE");
                List<Coupon> couponList = couponDao.getAllExpiredCoupons();
                for (Coupon c : couponList) {
                    couponDao.deleteCouponPurchaseCouponID(c.getId());
                    couponDao.deleteCoupon(c.getId());
                    System.out.println(c.toString() + "Was expired and deleted <SYSTEM WARNING>");
                }
                System.out.println("<SYSTEM WARNING> END SYSTEM DELETE");

        } catch (SQLException | CouponSystemException e) {
            System.out.println(e.getMessage());
        }


        try {
            Thread.sleep(1000);
//            Thread.sleep(1000*60*60*24);
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
    }


}
