/*
Creating by Zelma Milev
*/
package com.zm.facades;

import com.zm.beans.Category;
import com.zm.beans.ClientType;
import com.zm.beans.Company;
import com.zm.beans.Coupon;
import com.zm.exceptions.CouponSystemException;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class CompanyFacade extends ClientFacade {
    private int companyID;
/*
    optional
 */
    public CompanyFacade() {
        super();
    }

    public int getCompanyID() {
        return this.companyID;
    }

    public void setCompanyID(int companyID) {
        this.companyID = companyID;
    }

    public void addCoupon(Coupon coupon) throws SQLException, CouponSystemException {
        if (this.getCompanyID() != coupon.getCompanyId()) {
            throw new CouponSystemException("Wrong Company ID ");
        } else if (this.couponDao.isCompanyTheSameTitleCouponsExists(coupon.getCompanyId(), coupon.getTitle()))
            throw new CouponSystemException("Coupons with the same title exist ");

        else {
            this.couponDao.addCoupon(coupon);
        }

    }


    public void updateCoupon(Coupon coupon) throws SQLException, CouponSystemException {
        if (coupon.getCompanyId() !=  getCompanyID()) {
            throw new CouponSystemException("You can not change the Company  ID ");
        }
        if (!this.couponDao.isCouponExists(coupon.getId())) {
            throw new CouponSystemException("Target COUPON does not exist");
        }
        this.couponDao.updateCoupon(coupon);
    }

    public void deleteCoupon(int couponID) throws CouponSystemException, SQLException {
        if (!this.couponDao.isCouponExists(couponID)) {
            throw new CouponSystemException("Target COUPON does not exist");
        }
        this.couponDao.deleteCouponPurchaseCouponID (couponID);
        this.couponDao.deleteCoupon(couponID);
    }

    public Company getCompanyDetails() throws SQLException {
        return this.companyDao.getOneCompany(getCompanyID());
    }

    public List<Coupon> getCompanyCoupons() throws SQLException, CouponSystemException {
        if (!this.couponDao.isCompanyCouponsExists(getCompanyID())) {
            throw new CouponSystemException("The company has no coupons ");
        }
        return this.couponDao.getAllCompanyCoupons(getCompanyID());
    }

    public List<Coupon> getCompanyCoupons(Category category) throws SQLException, CouponSystemException {
        return getCompanyCoupons().stream().filter(coupon -> coupon.getCategoryId() == category.getVal()).collect(Collectors.toList());
    }

    public List<Coupon> getCompanyCoupons(double maxPrice) throws SQLException, CouponSystemException {
        return getCompanyCoupons().stream().filter(coupon -> coupon.getPrice() <= maxPrice).collect(Collectors.toList());

    }


    @Override
    public Boolean login(String email, String password) throws SQLException {
        return (this.companyDao.isCompanyExists(email, password));
    }
}
