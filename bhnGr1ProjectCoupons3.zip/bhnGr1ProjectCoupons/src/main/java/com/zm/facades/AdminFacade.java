/*
Creating by Zelma Milev
*/
package com.zm.facades;

import com.zm.beans.ClientType;
import com.zm.beans.Company;
import com.zm.beans.Customer;
import com.zm.exceptions.CouponSystemException;

import java.sql.SQLException;
import java.util.List;

public class AdminFacade extends ClientFacade {

    @Override
    public Boolean login(String email, String password) {
        return (email.equals("admin@admin.com") && password.equals("admin"));
    }

    public void addCompany(Company company) throws CouponSystemException, SQLException {

        if (this.companyDao.isNameOrEmailExist(company.getName(), company.getEmail())) {
            throw new CouponSystemException("Sorry name or email already exist...");
        }

        this.companyDao.addCompany(company);
    }

    public void updateCompany(Company company) throws SQLException, CouponSystemException {
        if (getOneCompany(company.getId()) == null) {
            System.out.println(("#" + company.getId() + " Unsuccessful update"));
        } else {
            Company companyDB = getOneCompany(company.getId());
            if (companyDB.getName().equalsIgnoreCase(company.getName())) {
                this.companyDao.updateCompany(company);
                System.out.println("#" + company.getId() + " Successfully updated");
            } else {
                System.out.println(("Sorry you try to change the name...Unsuccessful update"));
            }
        }
    }

    public void deleteCompany(int CompanyID) throws SQLException {
        if (this.companyDao.isCompanyExists(CompanyID)) {
            this.couponDao.deleteAllCompanyCoupons(CompanyID);
            this.companyDao.deleteCompany(CompanyID);
            System.out.println("#" + CompanyID + " Successfully deleted");
        } else {
            System.out.println("Sorry this company not exist...");

        }
    }

    public Company getOneCompany(int CompanyID) throws SQLException, CouponSystemException {
        if (this.companyDao.isCompanyExists(CompanyID)) {
            return this.companyDao.getOneCompany(CompanyID);

        } else {
            System.out.println("Sorry this company not exist...");
            return null;
        }
    }

    public List<Company> getAllCompanies() throws SQLException {
        return this.companyDao.getAllCompanies();
    }

    public void addCustomer(Customer customer) throws CouponSystemException, SQLException {

        if (this.customerDao.isEmailExist(customer.getEmail())) {
            throw new CouponSystemException("Sorry email already exist...");
        } else {
            this.customerDao.addCustomer(customer);
        }
    }

    public void updateCustomer(Customer customer) throws SQLException, CouponSystemException {
        if (this.customerDao.isCustomerExists( customer.getId()) ) {
            this.customerDao.updateCustomer(customer);
            System.out.println(("#" + customer.getId() + " Successfully updated"));

        } else {
            System.out.println(("#" + customer.getId() + " Unsuccessful update"));
        }
    }

    public void deleteCustomer(int CustomerID) throws SQLException, CouponSystemException {
        if (this.customerDao.isCustomerExists(CustomerID) ) {
            this.couponDao.deleteCouponPurchaseCustomerID(CustomerID);
            this.customerDao.deleteCustomer(CustomerID);
            System.out.println(("#" + CustomerID + " Successfully deleted"));

        } else {
            System.out.println(("#" + CustomerID + " Unsuccessful delete"));
        }
    }

    public Customer getOneCustomer(int CustomerID) throws SQLException, CouponSystemException {
        if (!this.customerDao.isCustomerExists(CustomerID) ) {
            System.out.println("Sorry customer #" + CustomerID + "not exist...");
        } else{             return this.customerDao.getOneCustomer(CustomerID);}
        return null;
    }

    public List<Customer> getAllCustomers() throws SQLException {
        return this.customerDao.getAllCustomers();
    }
}
