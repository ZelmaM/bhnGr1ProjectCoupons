/*
Creating by Zelma Milev
*/
package com.zm.dbdao;

import com.zm.beans.Coupon;
import com.zm.dao.CouponDao;
import com.zm.utils.DBUtils;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.zm.utils.DateUtils.convertToDataViaData;

public class CouponDBDAO implements CouponDao {
    private static final String QUERY_INSERT = "INSERT INTO `bhn_gr1_zm_pr1`.`coupons`" +
            " (`company_id`, `category_id`,`title`,`description`,`start_date`,`end_date`,`amount`,`price`,`image`) " +
            "VALUES ( ?, ?,?,?,?,?,?,?,?);\n";
    private static final String QUERY_UPDATE = "UPDATE `bhn_gr1_zm_pr1`.`coupons` SET " +
            "`company_id`=?, `category_id`=?,`title`=?,`description`=?,`start_date`=?," +
            "`end_date`=?,`amount`=?,`price`=?,`image`=? WHERE (`id` = ?);";
    private static final String QUERY_DELETE = "DELETE FROM `bhn_gr1_zm_pr1`.`coupons` WHERE (`id` = ?);";
    private static final String QUERY_DELETE_companies_coupons = "DELETE FROM `bhn_gr1_zm_pr1`.`coupons` WHERE (`company_id` = ?);";
    private static final String QUERY_GET_ONE = "SELECT * FROM `bhn_gr1_zm_pr1`.`coupons` WHERE (`id` = ?);";
    private static final String QUERY_GET_ALL = "SELECT * FROM `bhn_gr1_zm_pr1`.`coupons`";
    private static final String QUERY_GET_ALL_company = "SELECT * FROM `bhn_gr1_zm_pr1`.`coupons` WHERE (`company_id` = ?);";
    private static final String QUERY_GET_ALL_Expired = "SELECT * FROM `bhn_gr1_zm_pr1`.`coupons` WHERE (`end_date` < ?);";
    private static final String QUERY_GET_COUNT_endday = "SELECT COUNT(*) FROM `bhn_gr1_zm_pr1`.`coupons` WHERE (`end_date` < ?);";
    private static final String QUERY_GET_ALL_customer = "SELECT * FROM ( SELECT * FROM `bhn_gr1_zm_pr1`.`coupons`)   `a` INNER JOIN ( SELECT * FROM `bhn_gr1_zm_pr1`.`customers_vs_coupons` WHERE `customer_id` = ?)   `b` ON `a`.`id`= `b`.`coupon_id` ;";
    private static final String QUERY_INSERT_CUSTOMER_COUPON = "INSERT INTO `bhn_gr1_zm_pr1`.`customers_vs_coupons` (`customer_id`,`coupon_id` ) VALUES ( ?,?);\n";
    private static final String QUERY_DELETE_CUSTOMER_COUPON = "DELETE FROM `bhn_gr1_zm_pr1`.`customers_vs_coupons` WHERE (`customer_id` = ? AND `coupon_id`= ?);";
    private static final String QUERY_DELETE_CUSTOMER_COUPON_couponID = "DELETE FROM `bhn_gr1_zm_pr1`.`customers_vs_coupons` WHERE (`coupon_id`= ?);";
    private static final String QUERY_DELETE_CUSTOMER_COUPON_customerID = "DELETE FROM `bhn_gr1_zm_pr1`.`customers_vs_coupons` WHERE (`customer_id` = ? );";
    private static final String QUERY_GET_COUNT_companyid = "SELECT COUNT(*) FROM `bhn_gr1_zm_pr1`.`coupons` WHERE (`company_id` = ?);";
    private static final String QUERY_GET_COUNT_customerid = "SELECT COUNT(*) FROM `bhn_gr1_zm_pr1`.`customers_vs_coupons` WHERE (`customer_id` = ?);";
    private static final String QUERY_GET_COUNT_companyid_title = "SELECT COUNT(*) FROM `bhn_gr1_zm_pr1`.`coupons` WHERE (`company_id` = ? AND `title`=?);";

    @Override
    public void addCoupon(Coupon coupon) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, coupon.getCompanyId());
        map.put(2, coupon.getCategoryId());
        map.put(3, coupon.getTitle());
        map.put(4, coupon.getDescription());
        map.put(5, coupon.getStartDate());
        map.put(6, coupon.getEndDate());
        map.put(7, coupon.getAmount());
        map.put(8, coupon.getPrice());
        map.put(9, coupon.getImage());
        DBUtils.runStatement(QUERY_INSERT, map);
    }

    @Override
    public void updateCoupon(Coupon coupon) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, coupon.getCompanyId());
        map.put(2, coupon.getCategoryId());
        map.put(3, coupon.getTitle());
        map.put(4, coupon.getDescription());
        map.put(5, coupon.getStartDate());
        map.put(6, coupon.getEndDate());
        map.put(7, coupon.getAmount());
        map.put(8, coupon.getPrice());
        map.put(9, coupon.getImage());
        map.put(10, coupon.getId());
        DBUtils.runStatement(QUERY_UPDATE, map);
    }

    @Override
    public void deleteCoupon(int couponId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        DBUtils.runStatement(QUERY_DELETE, map);
    }

    @Override
    public void deleteAllCompanyCoupons(int companyId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        DBUtils.runStatement(QUERY_DELETE_companies_coupons);
    }

    @Override
    public boolean isCompanyCouponsExists(int companyId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_COUNT_companyid, map);
        resultSet.next();
        return resultSet.getInt(1) > 0;
    }

    @Override
    public boolean isCouponExists(int couponID) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponID);

        try {
            ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ONE, map);
            resultSet.next();
            int companyID = resultSet.getInt(2);
            return true;
        } catch (SQLException e) {
            System.out.println("Coupon #" + couponID + " is not exist <" + e.getMessage() + ">");
        }
        return false;
    }

    @Override
    public boolean isCustomerCouponExists(int customerID) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerID);
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_COUNT_customerid, map);
        resultSet.next();
        return resultSet.getInt(1) > 0;
    }

    @Override
    public boolean isExpiredCouponExists() throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, (LocalDate.now()));
            ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_COUNT_endday, map);
            resultSet.next();
            return resultSet.getInt(1) > 0;
        }

    public boolean isCompanyTheSameTitleCouponsExists(int companyId, String title) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        map.put(2, title);
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_COUNT_companyid_title, map);
        resultSet.next();
        return resultSet.getInt(1) > 0;
    }

    @Override
    public void addCouponPurchase(int customerId, int couponId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        map.put(2, couponId);

        DBUtils.runStatement(QUERY_INSERT_CUSTOMER_COUPON, map);
    }

    @Override
    public void deleteCouponPurchase(int customerId, int couponId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        map.put(2, couponId);

        DBUtils.runStatement(QUERY_DELETE_CUSTOMER_COUPON, map);
    }

    @Override
    public void deleteCouponPurchaseCustomerID(int customerId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);

        DBUtils.runStatement(QUERY_DELETE_CUSTOMER_COUPON_customerID, map);
    }

    @Override
    public void deleteCouponPurchaseCouponID(int couponId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);

        DBUtils.runStatement(QUERY_DELETE_CUSTOMER_COUPON_couponID, map);
    }

    @Override
    public Coupon getOneCoupon(int couponID) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponID);
        Coupon result = null;
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ONE, map);
        resultSet.next();
        int companyID = resultSet.getInt(2);
        int categoryID = resultSet.getInt(3);
        String title = resultSet.getString(4);
        String description = resultSet.getString(5);
        Date startDate = (Date) (resultSet.getDate(6));
        Date endDate = (Date) (resultSet.getDate(7));
        int amount = resultSet.getInt(8);
        double price = resultSet.getDouble(9);
        String image = resultSet.getString(10);
        result = new Coupon(couponID, companyID, categoryID, title, description, startDate, endDate, amount, price, image);
        return result;
    }

    @Override
    public List<Coupon> getAllCoupons() throws SQLException {
        List<Coupon> couponList = new ArrayList<>();
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ALL);
        while (resultSet.next()) {
            int couponID = resultSet.getInt(1);
            int companyID = resultSet.getInt(2);
            int categoryID = resultSet.getInt(3);
            String title = resultSet.getString(4);
            String description = resultSet.getString(5);
            Date startDate = (Date) (resultSet.getDate(6));
            Date endDate = (Date) (resultSet.getDate(7));
            int amount = resultSet.getInt(8);
            double price = resultSet.getDouble(9);
            String image = resultSet.getString(10);
            couponList.add(new Coupon(couponID, companyID, categoryID, title, description, startDate, endDate, amount, price, image));
        }
        return couponList;
    }

    @Override
    public List<Coupon> getAllCompanyCoupons(int companyID) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyID);
        List<Coupon> couponList = new ArrayList<>();
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ALL_company, map);
        while (resultSet.next()) {
            int couponID = resultSet.getInt(1);
            int categoryID = resultSet.getInt(3);
            String title = resultSet.getString(4);
            String description = resultSet.getString(5);
            Date startDate = (Date) (resultSet.getDate(6));
            Date endDate = (Date) (resultSet.getDate(7));
            int amount = resultSet.getInt(8);
            double price = resultSet.getDouble(9);
            String image = resultSet.getString(10);
            couponList.add(new Coupon(couponID, companyID, categoryID, title, description, startDate, endDate, amount, price, image));
        }
        return couponList;
    }

    @Override
    public List<Coupon> getAllCustomersCoupons(int customerId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        List<Coupon> couponList = new ArrayList<>();
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ALL_customer, map);
        while (resultSet.next()) {
            int couponID = resultSet.getInt(1);
            int companyID = resultSet.getInt(2);
            int categoryID = resultSet.getInt(3);
            String title = resultSet.getString(4);
            String description = resultSet.getString(5);
            Date startDate = (Date) (resultSet.getDate(6));
            Date endDate = (Date) (resultSet.getDate(7));
            int amount = resultSet.getInt(8);
            double price = resultSet.getDouble(9);
            String image = resultSet.getString(10);
            couponList.add(new Coupon(couponID, companyID, categoryID, title, description, startDate, endDate, amount, price, image));
        }
        return couponList;
    }

    @Override
    public List<Coupon> getAllExpiredCoupons() throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, (LocalDate.now()));
        List<Coupon> couponList = new ArrayList<>();
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ALL_Expired, map);
        while (resultSet.next()) {
            int couponID = resultSet.getInt(1);
            int companyID = resultSet.getInt(2);
            int categoryID = resultSet.getInt(3);
            String title = resultSet.getString(4);
            String description = resultSet.getString(5);
            Date startDate = (Date) (resultSet.getDate(6));
            Date endDate = (Date) (resultSet.getDate(7));
            int amount = resultSet.getInt(8);
            double price = resultSet.getDouble(9);
            String image = resultSet.getString(10);
            couponList.add(new Coupon(couponID, companyID, categoryID, title, description, startDate, endDate, amount, price, image));
        }
        return couponList;
    }
}
