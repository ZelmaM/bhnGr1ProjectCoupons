/*
Creating by Zelma Milev
*/
package com.zm.dbdao;

import com.zm.beans.Company;
import com.zm.dao.CompanyDao;
import com.zm.exceptions.CouponSystemException;
import com.zm.utils.DBUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CompanyDBDAO implements CompanyDao {
    private static final String QUERY_INSERT = "INSERT INTO `bhn_gr1_zm_pr1`.`companies` (`name`, `email`,`password`) VALUES ( ?, ?,?);\n";
    private static final String QUERY_UPDATE = "UPDATE `bhn_gr1_zm_pr1`.`companies` SET `name` = ?, `email` = ?, `password` = ? WHERE (`id` = ?);";
    private static final String QUERY_DELETE = "DELETE FROM `bhn_gr1_zm_pr1`.`companies` WHERE (`id` = ?);";
    private static final String QUERY_GET_ONE = "SELECT * FROM `bhn_gr1_zm_pr1`.`companies` WHERE (`id` = ?);";
    private static final String QUERY_GET_ID_PER_EMAIL_PASS = "SELECT (`id`) FROM `bhn_gr1_zm_pr1`.`companies` WHERE (`email` = ? AND `password` = ?);";
    private static final String QUERY_GET_COUNT_nameORpassword = "SELECT COUNT(*) FROM `bhn_gr1_zm_pr1`.`companies` WHERE (`name` = ? OR`password` = ?);";
    private static final String QUERY_GET_ALL = "SELECT * FROM `bhn_gr1_zm_pr1`.`companies`";

    @Override
    public void addCompany(Company company) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, company.getName());
        map.put(2, company.getEmail());
        map.put(3, company.getPassword());
        DBUtils.runStatement(QUERY_INSERT, map);
    }

    @Override
    public void updateCompany(Company company) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, company.getName());
        map.put(2, company.getEmail());
        map.put(3, company.getPassword());
        map.put(4, company.getId());
        DBUtils.runStatement(QUERY_UPDATE, map);
    }

    @Override
    public void deleteCompany(int companyId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        DBUtils.runStatement(QUERY_DELETE, map);
    }

    @Override

    public boolean isCompanyExists(String email, String password) {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, email);
        map.put(2, password);

        ResultSet resultSet = null;
        try {
            resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ID_PER_EMAIL_PASS, map);
            resultSet.next();
            int id = resultSet.getInt(1);
            return true;
        } catch (SQLException e) {
            System.out.println("Company is not exist"+ e.getMessage());
        }

        return false;
    }

    @Override
    public int getCompanyID(String email, String password) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, email);
        map.put(2, password);

        ResultSet resultSet = null;
        resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ID_PER_EMAIL_PASS, map);
        resultSet.next();
        return resultSet.getInt(1);
    }

    @Override
    public boolean isCompanyExists(int companyId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        try {
            ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ONE, map);
            resultSet.next();
            int id = resultSet.getInt(1);
            return true;
        } catch (SQLException e) {
            System.out.println("Company #" +companyId +" not exist " +"<"+ e.getMessage()+">");
        }
        return false;
    }

    @Override
    public Company getOneCompany(int companyId) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        Company result = null;
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ONE, map);
        resultSet.next();
        String name = resultSet.getString(2);
        String email = resultSet.getString(3);
        String password = resultSet.getString(4);
        result = new Company(companyId, name, email, password);
        return result;
    }

    @Override
    public List<Company> getAllCompanies() throws SQLException {
        List<Company> companyList = new ArrayList<>();
        ResultSet resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_ALL);
        while (resultSet.next()) {
            int id = resultSet.getInt(1);
            String name = resultSet.getString(2);
            String email = resultSet.getString(3);
            String password = resultSet.getString(4);
            companyList.add(new Company(id, name, email, password));
        }
        return companyList;
    }

    @Override
    public boolean isNameOrEmailExist(String name, String email) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, name);
        map.put(2, email);

        ResultSet resultSet = null;
        resultSet = DBUtils.runStatementWithResultSet(QUERY_GET_COUNT_nameORpassword, map);
        resultSet.next();
        return (resultSet.getInt(1) > 0) ;
    }
}
